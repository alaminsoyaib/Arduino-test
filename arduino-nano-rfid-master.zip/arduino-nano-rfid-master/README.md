# arduino-nano-rfid
<h1>Arduino Nano + RFID-RC522 - Arduino Tutorial</h1>
Download RFID RC522 MFRC522 Arduino Library

https://www.arduinolibraries.info/libraries/mfrc522
![RFID-RC522](https://3.bp.blogspot.com/-LIRYnr98scs/WxPHATmSfdI/AAAAAAABIlA/UzwXyHHkqCQpFBX0bW4NZXvnm_ARMAEDQCPcBGAYYCw/s1600/arduino-rfid-rc522-esquema.png)

[![Maker Tutor](https://img.youtube.com/vi/TJJ_1LiDDrc/0.jpg)](https://www.youtube.com/watch?v=TJJ_1LiDDrc)
